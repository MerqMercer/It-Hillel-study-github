<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subscription extends Model
{
    use HasFactory;

    public function notifications() {
        return $this->belongsToMany(User::class, 'notifications_subscriptions', 'subscription_id', 'notification_id')->withTimestamps();
    }

    public function user() {
        return $this->belongsTo(User::class);
    }

    public function card() {
        return $this->belongsTo(Card::class);
    }
}

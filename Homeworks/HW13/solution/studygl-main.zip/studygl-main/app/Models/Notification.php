<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    use HasFactory;

    public function subscriptions() {
        return $this->belongsToMany(User::class, 'notifications_subscriptions', 'notification_id', 'subscription_id')->withTimestamps();
    }

    public function card() {
        return $this->belongsTo(Card::class);
    }
}

<?php

namespace Database\Seeders;
use App\Models\User;
use App\Models\Board;
use App\Models\Card;
use App\Models\Column;
use App\Models\Comment;
use App\Models\Notification;
use App\Models\Subscription;
use App\Models\notification_subscription;
use App\Models\board_user;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $boards = [];
        $users = \App\Models\User::factory(10)->create();

        $users->each(function(User $user) {
            $board = \App\Models\Board::factory(1)->create(['author_id' => $user->id]);
            $user->boards()->sync($board);
        });

        Board::all()->each(function(Board $board){
            $column = \App\Models\Column::factory(1)->create(['board_id' => $board->id]);
        });

        Column::all()->each(function(Column $column) use ($users) {
            $cards = \App\Models\Card::factory(1)->create(['column_id' => $column->id,
                                                           'author_id' => $users->random()->id,
                                                           'executor_id' => $users->random()->id]);
        });

        Card::all()->each(function(Card $card) use ($users) {
            $comments = \App\Models\Comment::factory(1)->create(['card_id' => $card->id,
                                                                 'user_id' => $users->random()->id]);
            $notifications = \App\Models\Notification::factory(1)->create(['card_id' => $card->id]);
            $subscriptions = \App\Models\Subscription::factory(1)->create(['card_id' => $card->id,
                                                                           'user_id' => $users->random()->id]);
        });

        Notification::all()->each(function(Notification $notification) {
            $notification->subscriptions()->sync(Subscription::all()->random()->id);
        });

    }
}

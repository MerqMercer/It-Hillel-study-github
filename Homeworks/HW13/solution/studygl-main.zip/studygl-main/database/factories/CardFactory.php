<?php

namespace Database\Factories;
use App\Models\User;
use App\Models\Column;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Card>
 */
class CardFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'title' => $this->faker->sentence($nbWords = 6, $variableNbWords = true),
            'author_id' => User::factory(),
            'executor_id' => User::factory(),
            'column_id' => Column::factory(),
            'description' => $this->faker->paragraph($nbSentences = 3, $variableNbSentences = true),
        ];
    }
}
